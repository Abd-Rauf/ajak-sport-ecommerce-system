<div class="modal fade" id="terms" tabindex="-1"> 
    <div class="modal-dialog" style="width:50%">
        <div class="modal-content">
            <div class="modal-header">
                <button class="close" data-dismiss="modal" type="button">×</button>
            </div>

            <div class="modal-body"> 
                <p><h3><strong>Terma & Syarat Pembelian Online Ajak's Sport</strong></h3></p>

                <p>Terma ini mengikat anda sebagai pelanggan.</p>

                <p>Selamat datang ke sistem tempahan atas talian Ajak's Sport. Terima kasih kerana memilih kami.<br/>
                Terma ini mengawal penggunaan laman web dan pembelian produk anda dari kami.<br/>
                Dengan menggunakan laman web ini, anda bersetuju dengan terma ini seolah-olah anda telah menandatangani perjanjian yang sah.<br/></p>

                <p>Untuk sebarang pertanyaan, sila hubungi <strong>Ajak's Sport di +6013-3854531</strong> atau <strong>pusat kami di Presint 11, Putrajaya</strong>.</p>

                <br/><strong>HARGA</strong><br/>
                Harga produk kami dinyatakan di laman web dan dikemas kini dari semasa ke semasa.<br/>
                Semua harga adalah dalam Ringgit Malaysia (RM).<br/>

                <br/><strong>TEMPAHAN & PEMBAYARAN</strong><br/>
                Tempahan anda adalah tawaran untuk membeli. Perjanjian hanya wujud apabila pembayaran anda telah disahkan.<br/>
                Pembayaran penuh diperlukan semasa membuat tempahan.<br/>
                Setelah tempahan disahkan, anda terikat dengan tempahan tersebut.<br/>

                <br/><strong>PENGHANTARAN</strong><br/>
                Maklumat caj penghantaran boleh didapati di laman web kami.<br/>
                Tempahan yang dibuat sebelum jam 5 petang akan dihantar pada hari bekerja berikutnya.<br/>
                Sila masukkan alamat yang betul semasa membuat tempahan. Sekiranya salah, penghantaran semula akan dikenakan caj.<br/>

                <br/><strong>PEMBATALAN</strong><br/>
                Untuk membatalkan tempahan, sila hubungi kami dalam masa 24 jam selepas membuat tempahan.<br/>
                Kelewatan penghantaran bukan alasan sah untuk pembatalan dan tiada bayaran balik akan dibuat.<br/>

                <br/><strong>AMBIL SENDIRI</strong><br/>
                Semua produk sedia untuk diambil sendiri di Ajak's Sport, Presint 11 Putrajaya.<br/>
                Pembatalan mestilah dimaklumkan dalam masa 24 jam selepas pembelian.<br/>

                <br/><strong>HAKCIPTA</strong><br/>
                Laman web dan kandungannya adalah hak milik Ajak's Sport. Anda tidak boleh menyalin atau mengguna semula tanpa kebenaran.<br/>

                <br/><strong>PENAFIAN</strong><br/>
                Kami berusaha memastikan maklumat di laman ini tepat dan terkini. Namun, kami tidak bertanggungjawab ke atas sebarang kesilapan.<br/>

                <br/><strong>PERUBAHAN TERMA</strong><br/>
                Kami berhak untuk menukar terma dan syarat ini tanpa notis awal.<br/>

                <br/><strong>PRIVASI</strong><br/>
                Dengan menggunakan laman web kami, anda bersetuju dengan dasar privasi kami. Kami tidak akan berkongsi maklumat anda tanpa kebenaran.<br/>

                <br/><strong>UNDANG-UNDANG TERPAKAI</strong><br/>
                Terma ini ditadbir oleh undang-undang Malaysia, dan sebarang pertikaian akan dirujuk kepada mahkamah di Putrajaya.<br/>
            </div>

            <div class="modal-footer">
                <p align="left">&copy; Ajak's Sport E-Commerce System</p>
                <button class="btn btn-default" data-dismiss="modal" type="button">Close</button> 
                <button class="btn btn_fixnmix" name="btnsignup" type="submit">Sign Up</button> 
            </div> 
        </div>
    </div>
</div>