<!DOCTYPE html>
<html>
<head>
  <title>Terms and Conditions | Ajak's Sport</title>
  <style>
    body {
      font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
      padding: 30px;
      background-color: #fff;
      color: #333;
    }
    h3 {
      color: #e95420;
    }
    strong {
      color: #222;
    }
    footer {
      margin-top: 50px;
      border-top: 1px solid #ccc;
      padding-top: 20px;
    }
  </style>
</head>
<body>
  <div class="view">
    <h3><strong>Ajak's Sport Online Terms and Conditions</strong></h3>
    <p>Thank you for supporting <strong>Ajak's Sport</strong>. These terms apply when you purchase sports products through our website. Please read them carefully before placing your order.</p>

    <p><strong>PRICES</strong><br>
    All prices are stated in Malaysian Ringgit (RM). We reserve the right to update our prices at any time.</p>

    <p><strong>ORDERS & PAYMENTS</strong><br>
    All orders are confirmed upon successful payment or confirmation of Cash on Delivery. Orders placed cannot be changed unless agreed by the management. Payments can be made via online banking, e-wallet, or Cash on Delivery (COD).</p>

    <p><strong>DELIVERY</strong><br>
    Orders placed before 5:00 PM will be processed and shipped on the same day or the next working day. Delivery is available within Putrajaya and nearby areas. Ensure your delivery address is correct. Redelivery due to wrong address may incur additional charges.</p>

    <p><strong>PICK-UP OPTION</strong><br>
    Self-pickup is available at our outlet located at Pusat Kejiranan Presint 11, Putrajaya. Pickup time will be arranged after order confirmation.</p>

    <p><strong>RETURNS & EXCHANGE</strong><br>
    We accept returns for defective items within 7 days of delivery. Items must be unused and in original packaging. No refunds for change-of-mind purchases.</p>

    <p><strong>PRIVACY</strong><br>
    Your personal data will only be used for processing orders and providing customer service. We will not share your information without your consent.</p>

    <p><strong>COPYRIGHT</strong><br>
    All content and images on this website are owned by Ajak's Sport and may not be reused without permission.</p>

    <p><strong>CHANGES TO TERMS</strong><br>
    Ajak's Sport reserves the right to modify these terms at any time without prior notice.</p>

    <p>If you have any questions, please contact us at <strong>+6013-3854531</strong> or email <strong>ajaksport@gmail.com</strong>.</p>
  </div>

  <footer>
    <div class="form-group">
      <div class="col-md-10">
        <label class="col-md-4" align="right" for="image"></label>
        <div class="col-md-8">
          <p>
            <input type="checkbox" name="condition" value="checkbox" />
            <small>I agree to the 
              <a class="toggle-modal" onclick="OpenPopupCenter('terms.php','Terms and Conditions','600','600')">
                <b>TERMS AND CONDITIONS</b>
              </a> 
              of Ajak's Sport.
            </small>
          </p>
          <?php require_once 'terms.php'; ?>
        </div>
      </div>
    </div>
  </footer>
</body>
</html>