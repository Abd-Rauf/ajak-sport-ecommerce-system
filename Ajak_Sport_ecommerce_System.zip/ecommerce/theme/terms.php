<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Terms and Conditions | Ajak's Sport</title>
    <style>
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            line-height: 1.8;
            margin: 40px auto;
            padding: 20px;
            max-width: 900px;
            background-color: #fffaf5;
            color: #333;
        }
        h1, h2, h3 {
            color: #e95420;
        }
        ul {
            padding-left: 20px;
        }
        strong {
            color: #000;
        }
        .footer {
            text-align: center;
            margin-top: 50px;
            color: #999;
        }
    </style>
</head>
<body>

    <h1><strong>Syarat & Terma Perkhidmatan</strong></h1>
    <p>Selamat datang ke <strong>Ajak’s Sport</strong>. Dengan melayari dan membuat pembelian melalui laman web kami, anda bersetuju dengan syarat-syarat berikut:</p>

    <h2>1. Harga Produk</h2>
    <p>Semua harga adalah dalam Ringgit Malaysia (RM). Kami berhak untuk menukar harga pada bila-bila masa tanpa notis awal.</p>

    <h2>2. Pesanan & Pembayaran</h2>
    <ul>
        <li>Semua pesanan mestilah dibuat secara dalam talian melalui laman web rasmi kami.</li>
        <li>Pembayaran penuh diperlukan semasa proses checkout.</li>
        <li>Setelah pembayaran disahkan, pesanan tidak boleh dibatalkan melainkan dengan persetujuan pihak kami.</li>
    </ul>

    <h2>3. Penghantaran</h2>
    <p>Kami menyediakan penghantaran di seluruh Malaysia. Caj penghantaran bergantung pada lokasi dan jumlah belian. Pesanan akan diproses dalam tempoh 1-3 hari bekerja.</p>

    <h2>4. Pemulangan & Penukaran</h2>
    <p>Penukaran hanya dibenarkan dalam tempoh 7 hari selepas penerimaan barang, dan hanya untuk produk yang belum digunakan dan masih dalam pembungkusan asal. Kos penghantaran adalah tanggungjawab pelanggan.</p>

    <h2>5. Hak Cipta</h2>
    <p>Semua kandungan di laman web Ajak's Sport adalah hak milik kami. Sebarang penggunaan tanpa kebenaran bertulis adalah dilarang sama sekali.</p>

    <h2>6. Privasi Pengguna</h2>
    <p>Kami mengambil serius tentang keselamatan dan privasi maklumat peribadi anda. Maklumat anda tidak akan dikongsi kepada pihak ketiga tanpa kebenaran anda, kecuali untuk tujuan penghantaran dan pembayaran.</p>

    <h2>7. Pengecualian Tanggungjawab</h2>
    <p>Kami tidak bertanggungjawab atas sebarang kerosakan atau kehilangan akibat penggunaan produk yang tidak mengikut arahan atau disebabkan oleh kesilapan penghantaran oleh pihak ketiga.</p>

    <h2>8. Perubahan Syarat</h2>
    <p>Kami berhak mengubah terma dan syarat ini pada bila-bila masa. Sebarang perubahan akan dikemas kini di halaman ini.</p>

    <div class="footer">
        &copy; 2025 Ajak's Sport Store. All rights reserved.
    </div>

</body>
</html>