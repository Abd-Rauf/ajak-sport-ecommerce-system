<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Contact Us | Ajak's Sport</title>
  <link rel="stylesheet" href="../css/bootstrap.min.css">
  <link rel="stylesheet" href="../css/main.css">
</head>
<body style="padding: 30px; font-family: 'Roboto', sans-serif;">
  <div class="container">
    <h2>Contact Us</h2>
    <p>If you have any questions, feel free to get in touch with us.</p>
    <p><strong>Phone:</strong> <a href="tel:+6013-3854531">+6013-3854531</a></p>
    <p><strong>Email:</strong> <a href="mailto:ajaksport@gmail.com">ajaksport@gmail.com</a></p>
    <p><strong>Address:</strong> Pusat Kejiranan Presint 11, 62300, Putrajaya</p>
  </div>

  <form id="offlineForm">
  <input type="text" name="name" placeholder="Name" required><br><br>
  <input type="email" name="email" placeholder="Email" required><br><br>
  <input type="text" name="subject" placeholder="Subject" required><br><br>
  <textarea name="message" placeholder="Your Message Here" required></textarea><br><br>
  <button type="submit">Submit</button>
</form>

<script>
  document.getElementById('offlineForm').addEventListener('submit', function(e) {
    e.preventDefault(); // Hentikan form dari reload page
    alert("Thank you for contacting Ajak's Sport! We'll get back to you soon.");
    this.reset(); // Reset borang selepas hantar
  });
</script
</body>
</html>