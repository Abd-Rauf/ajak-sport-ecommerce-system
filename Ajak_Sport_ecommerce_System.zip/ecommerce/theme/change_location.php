<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Change Location | Ajak's Sport</title>
  <link rel="stylesheet" href="../css/bootstrap.min.css">
  <link rel="stylesheet" href="../css/main.css">
</head>
<body style="padding: 30px; font-family: 'Roboto', sans-serif;">
  <div class="container">
    <h2>Change Delivery Location</h2>
    <p>To change your shipping location:</p>
    <ol>
      <li>Login to your account.</li>
      <li>Go to <strong>Profile &gt; Addresses</strong></li>
      <li>Edit or Add New Address</li>
      <li>Save your changes before placing order.</li>
    </ol>
    <p>Need help? <a href="contact_us.php">Contact our support team</a>.</p>
  </div>
</body>
</html>