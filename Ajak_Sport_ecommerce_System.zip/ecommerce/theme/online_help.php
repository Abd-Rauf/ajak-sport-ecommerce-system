<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Online Help | Ajak's Sport</title>
  <link rel="stylesheet" href="../css/bootstrap.min.css">
  <link rel="stylesheet" href="../css/main.css">
</head>
<body style="padding: 30px; font-family: 'Roboto', sans-serif;">
  <div class="container">
    <h2>Online Help</h2>
    <p>Need assistance with using Ajak's Sport website? Our team is here to help!</p>
    <p>You may reach out to us via:</p>
    <ul>
      <li>📞 Phone: <a href="tel:+6013-3854531">+6013-3854531</a></li>
      <li>📧 Email: <a href="mailto:ajaksport@gmail.com">ajaksport@gmail.com</a></li>
    </ul>
    <p>We provide help for order tracking, payment issues, product info, and more.</p>
  </div>
</body>
</html>