<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Privacy Policy | Ajak's Sport</title>
    <link href="../css/bootstrap.min.css" rel="stylesheet">
    <link href="../css/font-awesome.min.css" rel="stylesheet">
    <link href="../css/main.css" rel="stylesheet">
    <style>
        body {
            padding: 40px;
            background-color: #fffefb;
            color: #333;
            font-family: Arial, sans-serif;
        }
        h2 {
            color: #e95420;
            margin-top: 30px;
        }
    </style>
</head>
<body>
    <div class="container">
        <h1><strong>Privacy Policy</strong></h1>
        <p>This privacy policy explains how <strong>Ajak's Sport</strong> collects, uses, and protects your personal information when you visit or make a purchase from our website.</p>

        <h2>1. Information We Collect</h2>
        <p>We may collect your name, email address, contact number, shipping address, and purchase details. This data is collected when you sign up, make a purchase, or contact us.</p>

        <h2>2. How We Use Your Information</h2>
        <ul>
            <li>To process transactions and deliver products.</li>
            <li>To send email updates and promotions.</li>
            <li>To improve our services and customer support.</li>
        </ul>

        <h2>3. Data Protection</h2>
        <p>We use secure servers and encryption to ensure that your personal data is protected and not misused.</p>

        <h2>4. Third-Party Disclosure</h2>
        <p>We do not sell, trade, or share your information to outside parties except those who help operate our website and deliver services, under confidentiality agreements.</p>

        <h2>5. Your Consent</h2>
        <p>By using our website, you agree to this privacy policy.</p>

        <h2>6. Changes to This Policy</h2>
        <p>Ajak's Sport reserves the right to update this privacy policy at any time. We encourage users to check this page regularly.</p>

        <hr>
        <p>For questions, contact us at: <br>
        📞 <a href="tel:+60133854531">+6013-3854531</a><br>
        📧 <a href="mailto:ajaksport@gmail.com">ajaksport@gmail.com</a></p>
    </div>
</body>
</html>