<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Order Status | Ajak's Sport</title>
  <link rel="stylesheet" href="../css/bootstrap.min.css">
  <link rel="stylesheet" href="../css/main.css">
</head>
<body style="padding: 30px; font-family: 'Roboto', sans-serif;">
  <div class="container">
    <h2>Check Your Order Status</h2>
    <p>If you have recently placed an order with us, please call or WhatsApp to confirm your status:</p>
    <ul>
      <li>📞 Hotline: <a href="tel:+6013-3854531">+6013-3854531</a></li>
      <li>💬 WhatsApp: <a href="https://wa.me/60133854531">+6013-3854531</a></li>
    </ul>
    <p>Or, check your order history via the <strong>Account</strong> section if you're logged in.</p>
  </div>
</body>
</html>