<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>FAQ | Ajak's Sport</title>
  <link rel="stylesheet" href="../css/bootstrap.min.css">
  <link rel="stylesheet" href="../css/main.css">
</head>
<body style="padding: 30px; font-family: 'Roboto', sans-serif;">
  <div class="container">
    <h2>Frequently Asked Questions (FAQ)</h2>
    <h4>1. What type of products are available?</h4>
    <p>We offer sportswear, rackets, shoes, bags, and more.</p>

    <h4>2. How do I pay?</h4>
    <p>You can pay via online banking, QR code, or cash on delivery (COD).</p>

    <h4>3. Can I return a product?</h4>
    <p>Yes, contact us within 3 days of receiving the item with valid proof.</p>

    <h4>4. How long does delivery take?</h4>
    <p>1–3 working days within Putrajaya area. Other locations may vary.</p>
  </div>
</body>
</html>